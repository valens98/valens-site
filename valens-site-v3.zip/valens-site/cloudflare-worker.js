/**
 * cloudflare-worker.js
 *
 * Proxy Cloudflare Worker → Google Gemini (free tier).
 *
 * SETUP (10 minuti, tutto gratis):
 * ─────────────────────────────────────────────────────
 * 1. Vai su https://dash.cloudflare.com → Workers & Pages → Create Worker
 * 2. Incolla TUTTO questo file nell'editor
 * 3. Clicca "Save and Deploy"
 * 4. Vai su Settings → Variables → aggiungi:
 *      GEMINI_API_KEY = <la tua chiave da aistudio.google.com/app/apikey>
 * 5. Copia l'URL del Worker (es. https://daniele-ai.tuonome.workers.dev)
 * 6. In js/chat-gemini.js sostituisci WORKER_URL con quell'URL
 *
 * Limiti gratuiti:
 *   Cloudflare Workers → 100.000 richieste/giorno GRATIS
 *   Gemini 2.0 Flash   → 1.500 richieste/giorno, 15 RPM GRATIS (no carta)
 */

// ── CONFIGURAZIONE ────────────────────────────────────
const ALLOWED_ORIGIN  = 'https://valens98.github.io'; // il tuo dominio
const MAX_PER_IP      = 10;   // messaggi per IP per finestra
const WINDOW_SECONDS  = 60;   // finestra in secondi
const MAX_MSG_LENGTH  = 400;  // caratteri max per messaggio
const MAX_TURNS       = 8;    // turni di storia conservati

const SYSTEM_PROMPT = `Sei l'assistente AI personale di Daniele Valenti, un Cybersecurity Engineer e ricercatore in AI.

Profilo:
- MSc Computer Science & AI — Sapienza Roma (in corso)
- BSc Ingegneria Informatica — Sapienza, tesi su sistema APHRODITE per la ISS
- Appassionato di crittografia avanzata: ZKP, Groth16, Schnorr
- Machine learning: PyTorch, LSTM, Reinforcement Learning, Autoencoder
- Cybersecurity: CTF, penetration testing, anomaly detection
- Collaborazioni: Cisco, Eni, Sapienza
- GitHub: github.com/valens98 — Roma, Italia

Regole:
- Rispondi SOLO in italiano
- Tono tecnico ma accessibile, entusiasta per AI e cybersecurity
- Massimo 3 paragrafi brevi
- Usa il backtick per i termini tecnici: \`Python\`, \`ZKP\`, ecc.
- Se la domanda è fuori tema, reindirizza gentilmente al profilo di Daniele
- Non inventare informazioni non presenti nel profilo`;

// ── RATE LIMIT (Cloudflare KV opzionale, fallback in-memory) ─
const ipMap = new Map();

function isRateLimited(ip) {
  const now   = Math.floor(Date.now() / 1000);
  const entry = ipMap.get(ip) || { count: 0, reset: now + WINDOW_SECONDS };

  if (now > entry.reset) { entry.count = 0; entry.reset = now + WINDOW_SECONDS; }
  if (entry.count >= MAX_PER_IP) return true;

  entry.count++;
  ipMap.set(ip, entry);
  return false;
}

// ── CORS HEADERS ─────────────────────────────────────
function corsHeaders(origin) {
  const allowed = origin === ALLOWED_ORIGIN || origin?.includes('localhost');
  return {
    'Access-Control-Allow-Origin':  allowed ? origin : ALLOWED_ORIGIN,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };
}

// ── MAIN HANDLER ─────────────────────────────────────
export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    const cors   = corsHeaders(origin);

    // Preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: cors });
    }

    // Solo POST
    if (request.method !== 'POST') {
      return new Response(JSON.stringify({ error: 'Metodo non permesso' }), {
        status: 405, headers: { ...cors, 'Content-Type': 'application/json' },
      });
    }

    // IP
    const ip = request.headers.get('CF-Connecting-IP') || '0.0.0.0';
    if (isRateLimited(ip)) {
      return new Response(
        JSON.stringify({ error: `Limite raggiunto (${MAX_PER_IP} messaggi/minuto). Riprova tra poco!` }),
        { status: 429, headers: { ...cors, 'Content-Type': 'application/json' } }
      );
    }

    // Parsing body
    let body;
    try { body = await request.json(); }
    catch {
      return new Response(JSON.stringify({ error: 'Body non valido.' }), {
        status: 400, headers: { ...cors, 'Content-Type': 'application/json' },
      });
    }

    const { messages } = body || {};
    if (!Array.isArray(messages) || !messages.length) {
      return new Response(JSON.stringify({ error: 'Messaggi mancanti.' }), {
        status: 400, headers: { ...cors, 'Content-Type': 'application/json' },
      });
    }

    // Validazione ultimo messaggio
    const lastMsg = messages.at(-1);
    if (typeof lastMsg?.content !== 'string' || !lastMsg.content.trim()) {
      return new Response(JSON.stringify({ error: 'Messaggio non valido.' }), {
        status: 400, headers: { ...cors, 'Content-Type': 'application/json' },
      });
    }
    if (lastMsg.content.length > MAX_MSG_LENGTH) {
      return new Response(
        JSON.stringify({ error: `Messaggio troppo lungo (max ${MAX_MSG_LENGTH} caratteri).` }),
        { status: 400, headers: { ...cors, 'Content-Type': 'application/json' } }
      );
    }

    // Tronca storia
    const history = messages.slice(-MAX_TURNS);

    // Converti formato OpenAI → Gemini
    // Gemini usa "contents" con "role: user/model" e "parts"
    const geminiContents = history.map(m => ({
      role:  m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    }));

    // Chiave API dalla variabile d'ambiente Cloudflare
    const apiKey = env.GEMINI_API_KEY;
    if (!apiKey) {
      return new Response(JSON.stringify({ error: 'Configurazione server mancante.' }), {
        status: 500, headers: { ...cors, 'Content-Type': 'application/json' },
      });
    }

    // Chiamata Gemini
    const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

    try {
      const geminiRes = await fetch(geminiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system_instruction: { parts: [{ text: SYSTEM_PROMPT }] },
          contents: geminiContents,
          generationConfig: {
            maxOutputTokens: 500,
            temperature:     0.7,
          },
          safetySettings: [
            { category: 'HARM_CATEGORY_HARASSMENT',        threshold: 'BLOCK_MEDIUM_AND_ABOVE' },
            { category: 'HARM_CATEGORY_HATE_SPEECH',       threshold: 'BLOCK_MEDIUM_AND_ABOVE' },
            { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_MEDIUM_AND_ABOVE' },
          ],
        }),
      });

      if (!geminiRes.ok) {
        const err = await geminiRes.text();
        console.error('Gemini error:', err);
        return new Response(JSON.stringify({ error: 'Errore dal modello AI.' }), {
          status: 502, headers: { ...cors, 'Content-Type': 'application/json' },
        });
      }

      const data  = await geminiRes.json();
      const reply = data.candidates?.[0]?.content?.parts?.[0]?.text || 'Nessuna risposta.';

      return new Response(JSON.stringify({ reply }), {
        status: 200, headers: { ...cors, 'Content-Type': 'application/json' },
      });

    } catch (err) {
      console.error('Worker fetch error:', err);
      return new Response(JSON.stringify({ error: 'Errore interno.' }), {
        status: 500, headers: { ...cors, 'Content-Type': 'application/json' },
      });
    }
  },
};
